import { useState } from 'react'

const Statistics=(props)=>{
  if(props.all===0){
    return(
      <div>No feedback given</div>
    )
  }
  return(
    <div>
      <StatisticLine text="good" value={props.good}></StatisticLine>
      <StatisticLine text="neutral" value={props.neutral}></StatisticLine>
      <StatisticLine text="bad" value={props.bad}></StatisticLine>
      <StatisticLine text="average" value={props.average}></StatisticLine>
      <StatisticLine text="positive" value={props.positive}></StatisticLine>
    </div>
  )
}
const StatisticLine=(props)=>{
  return(
    <div>
      <table>
      <tr>
        <td>{props.text}</td>
        <td>{props.value}</td>
      </tr>
      </table>
  </div> 
  )
}
const Button=(props)=>{
  return(
    <button style={{backgroundColor:"white",borderRadius:"5px"}} onClick={()=>props.theState(props.value+1)}>{props.text}</button>
  )
}

const App = () => {
  // save clicks of each button to its own state
  const [good, setGood] = useState(0)
  const [neutral, setNeutral] = useState(0)
  const [bad, setBad] = useState(0)
  let all=bad+good+neutral
  let average=(bad+good+neutral)/3
  let positive=(good/all)*100
  return (
    <div style={{paddingLeft:"20px"}}>
      <h1>give feedback</h1><br/>
      <Button text="good" value={good} theState={setGood}></Button>
      <Button text="bad" value={bad} theState={setBad}></Button>
      <Button text="neutral" value={neutral} theState={setNeutral}></Button>
      <h2>statistics</h2>
      <Statistics all={all} good={good} bad={bad} neutral={neutral} average={average} positive={positive}>
      </Statistics>
      </div>
    )   
   
}

export default App
